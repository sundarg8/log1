#include "NxProcObj.h"
#include <iostream>

#if 1
NxProcObj::NxProcObj()
{
    //ctor
}
#endif // 0

#if 1
NxProcObj::~NxProcObj()
{
    //dtor
}
#endif


